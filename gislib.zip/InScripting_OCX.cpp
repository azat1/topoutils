// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// C++ TLBWRTR : $Revision:   1.134.1.39  $
// File generated on 26.01.2005 22:36:21 from Type Library described below.

// ************************************************************************ //
// Type Lib: E:\Program Files\Integro\InGeo\InGeo.exe\100 (1)
// IID\LCID: {3605F781-82BF-11D3-9665-000021C6D845}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (E:\WINDOWS\system32\stdole2.tlb)
// Parent TypeLibrary:
//   (0) v1.0 Ingeo, (InGeo.tlb)
// Errors:
//   Hint: Symbol 'Update' renamed to '_Update'
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#if defined(USING_ATL)
#include <atl\atlvcl.h>
#endif

#include "InScripting_OCX.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Inscripting_tlb
{


};     // namespace Inscripting_tlb
